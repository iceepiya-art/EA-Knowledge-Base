# Support And Delivery Message

## Message To Customer

สวัสดีครับ คุณ Zip Test

ผมเตรียมแพ็กเกจ CME / AlphaEdge SMC Pro ให้แล้วครับ

ข้อมูลสำคัญ:
- Package: Lifetime 1 account
- License Key: CMEALPHAED-ZIPTES-260505171556
- Account Lock: 12345678
- Expiry: ไม่จำกัด / ยังไม่ได้ระบุ

ก่อนใช้งานจริง แนะนำให้ติดตั้งและทดสอบในบัญชี demo หรือ lot ต่ำก่อนทุกครั้งนะครับ
ระบบนี้เป็นเครื่องมือช่วยเทรด/ช่วยตัดสินใจ ไม่ใช่การการันตีกำไร

## Support Checklist

- [ ] Customer received file/package
- [ ] Customer received license key
- [ ] Setup call scheduled
- [ ] Installation completed
- [ ] Default settings explained
- [ ] Risk settings explained
- [ ] Customer confirmed system is visible/running
