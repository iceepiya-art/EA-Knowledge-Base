# License Delivery

Created: 2026-05-05 17:15:56

## Customer

- Name: Zip Test
- Contact: LINE zip
- Product: CME / AlphaEdge SMC Pro
- Package: Lifetime 1 account
- Payment status: Paid
- Amount: 4999
- Account lock: 12345678
- Expiry: No expiry set

## License Key

```text
CMEALPHAED-ZIPTES-260505171556
```

## Admin Notes

zip test
