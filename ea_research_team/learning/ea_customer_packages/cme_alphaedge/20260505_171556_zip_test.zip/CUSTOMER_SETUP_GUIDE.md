# Customer Setup Guide

Product: CME / AlphaEdge SMC Pro

## Before Installing

1. Confirm platform version and broker account.
2. Confirm account number if this package is account-locked.
3. Confirm customer understands risk and no-profit-guarantee boundaries.
4. Send only the correct file for this package type.

## Suggested Setup Call Script

1. Ask customer to open MT5 or TradingView.
2. Install the EA/indicator together.
3. Apply recommended default settings.
4. Explain risk settings and what not to change.
5. Show how to remove/disable the system.
6. Confirm customer can see the signal/status panel.

## Product Notes

- Focus: CME option levels + SMC + risk panel + customer package.
- Best market/stage: GC / NQ / Prop futures / Customer package ready
- Next internal action: Compile Pine in TradingView, then test customer delivery flow.
